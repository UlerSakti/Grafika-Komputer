import numpy as np
import matplotlib.pyplot as plt

# =============================================================================
# 1. PUSTAKA FUNGSI TRANSFORMASI (MENGEMBALIKAN MATRIKS 3x3)
# =============================================================================

def matriks_translasi(tx, ty):
    """Menghasilkan matriks homogen 3x3 untuk translasi."""
    return np.array([
        [1, 0, tx],
        [0, 1, ty],
        [0, 0,  1]
    ], dtype=float)

def matriks_skala(sx, sy):
    """Menghasilkan matriks homogen 3x3 untuk penskalaan."""
    return np.array([
        [sx,  0, 0],
        [ 0, sy, 0],
        [ 0,  0, 1]
    ], dtype=float)

def matriks_rotasi(sudut_derajat):
    """Menghasilkan matriks homogen 3x3 untuk rotasi sudut derajat."""
    rad = np.radians(sudut_derajat)
    c, s = np.cos(rad), np.sin(rad)
    return np.array([
        [c, -s, 0],
        [s,  c, 0],
        [0,  0, 1]
    ], dtype=float)

def matriks_shear(shx=0, shy=0):
    """Menghasilkan matriks homogen 3x3 untuk shear."""
    return np.array([
        [  1, shx, 0],
        [shy,   1, 0],
        [  0,   0, 1]
    ], dtype=float)

def matriks_refleksi(sumbu='y'):
    """Menghasilkan matriks homogen 3x3 untuk refleksi."""
    sumbu = sumbu.lower()
    if sumbu == 'x':
        return np.array([
            [1,  0, 0],
            [0, -1, 0],
            [0,  0, 1]
        ], dtype=float)
    elif sumbu == 'y':
        return np.array([
            [-1, 0, 0],
            [ 0, 1, 0],
            [ 0, 0, 1]
        ], dtype=float)
    elif sumbu == 'origin':
        return np.array([
            [-1,  0, 0],
            [ 0, -1, 0],
            [ 0,  0, 1]
        ], dtype=float)
    elif sumbu == 'y=x':
        return np.array([
            [0, 1, 0],
            [1, 0, 0],
            [0, 0, 1]
        ], dtype=float)
    else:
        raise ValueError("Sumbu refleksi tidak valid. Pilih: 'x', 'y', 'origin', atau 'y=x'")

def apply_transformation(matrix, vertices):
    """Mengalikan matriks transformasi 3x3 dengan array verteks N x 2."""
    num_pts = vertices.shape[0]
    # Konversi ke koordinat homogen (3 x N)
    homo_vertices = np.hstack([vertices, np.ones((num_pts, 1))]).T
    
    # Perkalian matriks
    transformed_homo = np.dot(matrix, homo_vertices)
    
    # Konversi kembali ke koordinat Kartesius (N x 2)
    return transformed_homo[:2, :].T

# =============================================================================
# 2. FUNGSI KOMPOSISI TRANSFORMASI (PIVOT POINT)
# =============================================================================

def transformasi_terhadap_pivot(verteks, sudut_derajat, xp, yp):
    """
    Membangun matriks komposit T(xp, yp) * R(theta) * T(-xp, -yp) 
    dan menerapkannya pada verteks.
    """
    t_minus = matriks_translasi(-xp, -yp)
    r_theta = matriks_rotasi(sudut_derajat)
    t_plus  = matriks_translasi(xp, yp)
    
    # Matriks Komposit M = T(xp,yp) @ R(theta) @ T(-xp,-yp)
    m_composite = np.dot(t_plus, np.dot(r_theta, t_minus))
    
    return apply_transformation(m_composite, verteks)

# =============================================================================
# 3. STUDI KASUS VISUALISASI MATPLOTLIB
# =============================================================================

def main():
    # Definisikan Objek Tak Simetris (Panah Navigasi - 7 Verteks)
    # Bentuk ditutup dengan mengulang verteks awal di akhir
    panah_asli = np.array([
        [0, 0],
        [2, 0],
        [2, 1],
        [4, 1],
        [4, 2],
        [6, 0.5],
        [4, -1],
        [4, 0],
        [2, 0],  # Penutup jalur
        [0, 0]
    ], dtype=float)

    # Hitung Titik Berat / Centroid (x_bar, y_bar) secara otomatis
    # Digunakan verteks unik (tanpa titik penutup berulang)
    unique_vertices = panah_asli[:-1]
    cx = np.mean(unique_vertices[:, 0])
    cy = np.mean(unique_vertices[:, 1])

    # -------------------------------------------------------------------------
    # SUBPLOT 1: Rotasi Poros Sendiri (Centroid) 60 Derajat
    # -------------------------------------------------------------------------
    panah_rotasi = transformasi_terhadap_pivot(panah_asli, 60, cx, cy)

    # -------------------------------------------------------------------------
    # SUBPLOT 2: Shear Horizontal (shx=0.75) dilanjutkan Refleksi Sumbu Y
    # -------------------------------------------------------------------------
    m_shear = matriks_shear(shx=0.75, shy=0)
    m_refl  = matriks_refleksi(sumbu='y')
    
    # Komposisi: M_total = Refleksi @ Shear
    m_shear_refl = np.dot(m_refl, m_shear)
    panah_shear_refl = apply_transformation(m_shear_refl, panah_asli)

    # -------------------------------------------------------------------------
    # RENDERING MATPLOTLIB
    # -------------------------------------------------------------------------
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))

    # Subplot 1
    ax1.plot(panah_asli[:, 0], panah_asli[:, 1], 'b-o', label='Objek Asli', linewidth=2)
    ax1.plot(panah_rotasi[:, 0], panah_rotasi[:, 1], 'r-s', label='Rotasi 60° (Pivot Centroid)', linewidth=2)
    ax1.plot(cx, cy, 'go', markersize=10, label=f'Centroid ({cx:.2f}, {cy:.2f})')
    
    ax1.set_title('Subplot 1: Rotasi terhadap Pusat Massa (Centroid)', fontsize=11, fontweight='bold')
    ax1.set_xlabel('X')
    ax1.set_ylabel('Y')
    ax1.axhline(0, color='black', linewidth=0.8, linestyle='--')
    ax1.axvline(0, color='black', linewidth=0.8, linestyle='--')
    ax1.grid(True, linestyle=':', alpha=0.7)
    ax1.axis('equal')
    ax1.legend(loc='upper left')

    # Subplot 2
    ax2.plot(panah_asli[:, 0], panah_asli[:, 1], 'b-o', label='Objek Asli', linewidth=2)
    ax2.plot(panah_shear_refl[:, 0], panah_shear_refl[:, 1], 'm-^', label='Shear (0.75) + Refleksi Y', linewidth=2)
    
    ax2.set_title('Subplot 2: Shear Horizontal dilanjutkan Refleksi Sumbu Y', fontsize=11, fontweight='bold')
    ax2.set_xlabel('X')
    ax2.set_ylabel('Y')
    ax2.axhline(0, color='black', linewidth=0.8, linestyle='--')
    ax2.axvline(0, color='black', linewidth=0.8, linestyle='--')
    ax2.grid(True, linestyle=':', alpha=0.7)
    ax2.axis('equal')
    ax2.legend(loc='upper left')

    plt.tight_layout()
    plt.show()

if __name__ == '__main__':
    main()